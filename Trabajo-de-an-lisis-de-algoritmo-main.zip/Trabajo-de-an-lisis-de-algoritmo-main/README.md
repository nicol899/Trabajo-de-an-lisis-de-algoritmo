# Ejercicio taller de análisis de algoritmo
# Problema 1: Orientación de 3 puntos (Robot autónomo)

Para determinar la orientación se utiliza la fórmula del determinante (producto cruzado):


Det = (x_b - x_a)(y_c - y_a) - (y_b - y_a)(x_c - x_a)

- Det > 0: Giro a la izquierda (Antihorario)
- Det < 0: Giro a la derecha (Horario)
- Det = 0: Colineal (en línea recta)

- Caso 1 (a(4,2), b(5,3), c(3,7)):Det = (5-4)(7-2) - (3-2)(3-4) = (1)(5) - (1)(-1) = 6 Antihorario

- Caso 2 (a(2,7), b(6,5), c(8,2)):Det = (6-2)(2-7) - (5-7)(8-2) = (4)(-5) - (-2)(6) = -8 Horario

- Caso 3 (a(1,7), b(3,3), c(6,6)):Det = (3-1)(6-7) - (3-7)(6-1) = (2)(-1) - (-4)(5) = 18 Antihorario

- Caso 4 (a(0,4), b(5,4), c(3,1)):Det = (5-0)(1-4) - (4-4)(3-0) = (5)(-3) - 0 = -15 Horario

- Complejidad T(n):O(1). 

- Función en Python:
  
 def orientacion_robot(a, b, c):
    det = (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0])
    if det > 0:
        return "Antihorario"
    elif det < 0:
        return "Horario"
    else:
        return "Colineal"
      

# Problema 2: Intersección de segmentos (Autos autónomos)

- ¿Por qué las interacciones de dos segmentos tienen complejidad O(1)?
 Porque al evaluar si dos segmentos se cruzan solo requiere calcular cuatro orientaciones utilizando las coordenadas de sus 4 puntos extremos. 

- Resultados analíticos de los casos:

- Caso 1: El segmento (1,1)-(7,7) y (2,6)-(8,1) se cruzan.
- Caso 2: El segmento (1,7)-(3,3) y (5,5)-(7,7) no se cruzan.
- Caso 3: El segmento (0,2)-(6,2) y (3,2)-(9,2) presentan superposición (colineales).

- Función en Python:

  def orientacion(p, q, r):
    return (q[0] - p[0]) * (r[1] - p[1]) - (q[1] - p[1]) * (r[0] - p[0])

def se_cruzan(p1, q1, p2, q2):
    o1 = orientacion(p1, q1, p2)
    o2 = orientacion(p1, q1, q2)
    o3 = orientacion(p2, q2, p1)
    o4 = orientacion(p2, q2, q1)
    return ((o1 > 0 and o2 < 0) or (o1 < 0 and o2 > 0)) and \
           ((o3 > 0 and o4 < 0) or (o3 < 0 and o4 > 0))

# Problema 3: Triangulación de polígonos

1. Vértices convexos y cóncavos: Se identifican calculando la orientación del determinante de cada vértice con sus vecinos inmediatos (giro antihorario = convexo; giro horario = cóncavo).

2. Triángulos y diagonales: Para un polígono de n vértices, se requieren n - 2 triángulos y n - 3 diagonales internas.

3. Primera oreja (_Ear Clipping_): Es un triángulo formado por tres vértices consecutivos donde el vértice central es convexo y su diagonal interna no cruza ninguna arista exterior.
 
4. Condiciones previas: Verificar que el vértice central sea convexo y que ningún otro vértice del polígono esté contenido dentro de esa oreja.

5. Función en Python:

   def calcular_triangulation(n):
    return {"triangulos": n - 2, "diagonales_internas": n - 3}

# Problema 4: Red de acueducto (Intersección de tuberías)

1. Por qué el segundo bucle empieza en i + 1: Sirve para evitar comparar una tubería con ella misma y que se dupliquen los pares.

2. Tabla de iteraciones:
  
- Para n = 5: 4 + 3 + 2 + 1 = 10 llamadas.
- Para n = 8: 7 + 6 + 5 + 4 + 3 + 2 + 1 = 28 llamadas.

3. Complejidad temporal: O(n^2).

4. Cálculo de comprobaciones:

- Para n = 100: 100(99)/2 = 4,950 comprobaciones.
- Para n = 1000: 1000(999)/2 = 499,500 comprobaciones.
- Para n = 10000: 10000(9999)/2 = 49,995,000 comprobaciones.


# Problema 5: Terreno irregular

- Vértices dados: A(0,0), B(8,0), C(8,6), D(4,3), E(0,6). El vértice D(4,3) es cóncavo.

- Triangulación en 3 regiones:

    1. Triángulo ABD: A(0,0), B(8,0), D(4,3)  Área = 12 u^2
    2. Triángulo BCD: B(8,0), C(8,6), D(4,3) Área = 12 u^2
    3. Triángulo DEA: D(4,3), E(0,6), A(0,0) Área = 12 u^2

- Superficie total: 12 + 12 + 12 = 36 unidades cuadradas.

# Problema 6: Comparación de algoritmos (O(n^3) vs O(n^2))

Modelos de complejidad: T_A(n) = n^3 (Algoritmo A) y T_B(n) = n^2 (Algoritmo B).


- Cálculos y tabla comparativa:

nnn     Algoritmo A (TA=n3T_A = n^3TA​=n3)   Algoritmo B (TB=n2T_B = n^2TB​=n2)   Razón (TA/TBT_A / T_BTA​/TB​)
10                1.000                              100                                    10
100             1.000.000                           10.000                                  100
1.000         1.000.000.000                       1.000.000                                1.000

Conclusión: Conviene utilizar el Algoritmo B O(n^2), porque el sistema al utilizar T_A(n) = n^3 se vuelve muy lento cuando tiene que procesar muchos datos, haciendo que sea imposible usarlo en terrenos grandes.
